using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Weapon
{
    Pistol,
    Revolver,
    Rifile
}

public class GlobalValue
{
}
